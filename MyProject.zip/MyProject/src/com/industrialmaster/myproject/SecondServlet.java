package com.industrialmaster.myproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/second")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	Date startTime;
	
	@Override
	public void init() throws ServletException {
		System.out.println("Servlet Initializing........");
		startTime = new Date();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("Hello");
		out.println("<h5>Start Time: " +startTime+"</h5>");
		System.out.println("Serving..........");
	}
	
	@Override
	public void destroy() {
		System.out.println("Servlet Destroying..........");
		startTime = null;
	}

}
